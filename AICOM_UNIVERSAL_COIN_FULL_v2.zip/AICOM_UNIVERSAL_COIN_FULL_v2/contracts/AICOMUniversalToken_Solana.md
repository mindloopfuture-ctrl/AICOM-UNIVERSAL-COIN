# AICOM SPL Token (Solana)
Use este archivo solo como referencia.

1. Crear token SPL:
   spl-token create-token
2. Crear cuenta:
   spl-token create-account <TOKEN_MINT>
3. Mintear supply:
   spl-token mint <TOKEN_MINT> 1000000000

Anclar nombre resolviendo contra el resolver AICOM.
